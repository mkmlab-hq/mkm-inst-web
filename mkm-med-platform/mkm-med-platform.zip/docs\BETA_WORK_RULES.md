# Beta Version Work Rules (MKM Lab)

## 📋 Reference Index for All Contributors

**Whenever you start a new session or task, you MUST read and understand the following documents. These are the only official sources for all development, architecture, and workflow decisions in the MKM Lab Beta version.**

---

### 1. [PROJECT_MODULAR_STRATEGY_FINAL.md]
- **Purpose:** The official modular architecture constitution and technical standard for all code and workflow.
- **Summary:** All features must be developed as independent, testable, and composable modules ("Lego block" principle). Storybook (UI) and Swagger (API) are mandatory. Git Flow is required for all branches and reviews.

### 2. [MKM_COMPLETE_CONSTITUTION_v5.0_FINAL.md]
- **Purpose:** The philosophical and legal foundation of the project, including medical safety, privacy, risk management, and developer oath.
- **Summary:** All code must prioritize patient safety, privacy, and modularity. The developer oath and Prime Directive are binding for all contributors. Includes comprehensive risk management and quality assurance protocols.

### 3. [MKM_OFFICIAL_WHITEPAPER_v5.0_FINAL.md]
- **Purpose:** Official business strategy, technology whitepaper, and comprehensive project documentation.
- **Summary:** Dual-mode B2B2C strategy, modular architecture technical details, IP strategy, market positioning, and future roadmap. Single source of truth for all strategic decisions.

### 4. [DEVELOPMENT_PROTOCOL.md]
- **Purpose:** Practical guide for the development environment, stack, and workflow.
- **Summary:** Vue.js 3 + Firebase stack, Storybook/Swagger integration, and detailed workflow for daily development.

### 5. [CONTEXT_BRIEFING_v6.0.md]
- **Purpose:** Business and product context, B2B2C model, and platform vision.
- **Summary:** The project is a 4-type constitution-based AI health platform with a dual-mode (patient/expert) and single entry point.

### 6. [BETA_CORE_GUIDE.md]
- **Purpose:** Quick reference for immediate action, checklists, and code examples.
- **Summary:** Step-by-step instructions for Storybook, Swagger, branch strategy, and review checklist.

### 7. [MKM_DESIGN_SYSTEM_v8.0.md]
- **Purpose:** Complete design system and UI/UX implementation guidelines.
- **Summary:** Color system, typography, component library, mobile app architecture, web dashboard layout, and interaction patterns. Includes "Recording is Light, Insight is Deep" design philosophy and complete implementation checklist.

---

## 🚦 How to Use

- **At the start of every session, say:**
  > "Please review and internalize the Beta Version Work Rules. All work must strictly follow the latest official documents listed."
- **AI and all contributors must treat this file as the single source of truth for the Beta version.**
- **Delete or ignore any files not listed above.**

---

## 🗑️ File Cleanup Policy

- **Only the above 7 documents and essential code/config files should remain in the docs/ directory.**
- **All other outdated, backup, or redundant documentation files must be deleted to avoid confusion.**

---

**Last updated:** 2025-07-08
