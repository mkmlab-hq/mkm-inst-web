# 📋 **MKM Lab 프로젝트 마스터 인덱스 v3.0**
**"매일의 혁명, 평생의 진화" - 투-트랙 전략 시대**

## 📅 **업데이트 정보**
- **최종 수정**: 2025년 7월 11일
- **버전**: 3.0 (투-트랙 전략 반영)
- **상태**: 🟢 Active Development

---

## 🌟 **핵심 비전 & 전략**

### 🎯 **통합 사명**
**"개인의 건강 데이터를 통해 더 깊은 이해와 통제권을 제공하여, 모든 인류가 더 건강한 삶을 살도록 돕는다"**

### 🚀 **투-트랙 전략**
1. **MKM Lab (국내 B2B2C)**: 카카오톡 기반 의료기관 솔루션
2. **Mollynote (글로벌 B2C)**: 텔레그램 기반 AI 건강 동반자

---

## 📚 **핵심 문서 체계**

### 🏛️ **헌법 & 백서 (Constitution & Whitepaper)**
| 문서명 | 버전 | 상태 | 설명 |
|--------|------|------|------|
| **[MKM Lab 헌법 v7.0](./MKM_COMPLETE_CONSTITUTION_v7.0_FINAL.md)** | 7.0 | ✅ 최신 | 투-트랙 전략 반영 통합 헌법 |
| **[Mollynote 글로벌 백서 v2.0](./MOLLYNOTE_GLOBAL_WHITEPAPER_v2.0_FINAL.md)** | 2.0 | ✅ 최신 | AI 페르소나 브리핑 킬러 피처 |
| [MKM Lab 헌법 v5.0](./MKM_COMPLETE_CONSTITUTION_v5.0_FINAL.md) | 5.0 | 📚 참고 | 이전 버전 (모듈러 아키텍처) |

### 🎨 **디자인 시스템**
| 문서명 | 버전 | 상태 | 설명 |
|--------|------|------|------|
| **[MKM 디자인 시스템 v8.0](./MKM_DESIGN_SYSTEM_v8.0.md)** | 8.0 | ✅ 최신 | 투-트랙 브랜딩 통합 |

### 📋 **작업 규칙 & 가이드**
| 문서명 | 버전 | 상태 | 설명 |
|--------|------|------|------|
| **[베타 작업 규칙](./BETA_WORK_RULES.md)** | 1.0 | ✅ 최신 | 개발팀 작업 가이드라인 |
| **[베타 핵심 가이드](./BETA_CORE_GUIDE.md)** | 1.0 | ✅ 최신 | 개발 우선순위 및 방향성 |

### 📊 **전략 & 브리핑**
| 문서명 | 버전 | 상태 | 설명 |
|--------|------|------|------|
| **[프로젝트 모듈러 전략](./PROJECT_MODULAR_STRATEGY_FINAL.md)** | Final | ✅ 최신 | 기술 아키텍처 전략 |
| **[Molly AI 서비스 전략](./MOLLY_AI_SERVICE_STRATEGY_FINAL.md)** | Final | ✅ 최신 | AI 서비스 구현 전략 |
| **[컨텍스트 브리핑 v6.0](./CONTEXT_BRIEFING_v6.0.md)** | 6.0 | ✅ 최신 | 프로젝트 전체 맥락 |

---

## 🚀 **현재 개발 현황**

### ✅ **완료된 것들**
1. **백엔드 API 시스템 (100%)**
   - Firebase Functions 기반 서버 구축
   - 사용자 인증, 건강 노트, 문진 API 완성
   - Swagger UI 자동 문서화
   - 카카오톡 웹훅 연동 완료

2. **카카오톡 챗봇 연동 (95%)**
   - 오픈빌더 봇 생성 및 설정
   - 웹훅 API 연결 완료
   - 배포 준비 상태

3. **원장용 대시보드 (80%)**
   - 실시간 환자 목록 웹 인터페이스
   - 개별 환자 상세 정보 모달
   - 반응형 디자인 적용

4. **문서화 시스템 (100%)**
   - 헌법 v7.0, 백서 v2.0 최신화
   - 실전 배포 가이드 완성
   - API 문서 자동 생성

### 🔄 **진행 중인 것들**
1. **AI 분석 엔진 개발 (30%)**
   - 음성 분석 모듈
   - 설진 이미지 분석
   - 페르소나 매핑 시스템

2. **Mollynote 글로벌 버전 (10%)**
   - 텔레그램 봇 초기 설계
   - rPPG 기술 연구
   - 페르소나 아키타입 정의

### 📋 **다음 우선순위**
1. **카카오톡 챗봇 실제 배포 및 테스트**
2. **원장용 대시보드 완성**
3. **AI 분석 엔진 MVP 개발**
4. **Mollynote 텔레그램 봇 프로토타입**

---

## 🛠️ **기술 스택**

### **Backend**
- **Firebase Functions**: 서버리스 백엔드
- **Firestore**: NoSQL 데이터베이스
- **Express.js**: API 프레임워크
- **Swagger**: API 문서화

### **Frontend**
- **Vue.js 3**: 대시보드 프론트엔드
- **Tailwind CSS**: 유틸리티 CSS 프레임워크
- **Chart.js**: 데이터 시각화

### **Chatbot**
- **카카오 i 오픈빌더**: 국내 챗봇 플랫폼
- **Telegram Bot API**: 글로벌 챗봇 플랫폼

### **AI/ML**
- **OpenCV**: 이미지 처리
- **TensorFlow.js**: 클라이언트 사이드 ML
- **Python**: AI 모델 개발

---

## 📁 **프로젝트 구조**

```
mkmlab-v3/
├── docs/                           # 📚 문서
│   ├── MKM_COMPLETE_CONSTITUTION_v7.0_FINAL.md
│   ├── MOLLYNOTE_GLOBAL_WHITEPAPER_v2.0_FINAL.md
│   ├── MKM_DESIGN_SYSTEM_v8.0.md
│   └── ...
├── functions/                      # 🔥 Firebase Functions
│   ├── index.js                   # 메인 API 서버
│   ├── src/routes/                # API 라우터
│   └── swagger.js                 # API 문서
├── frontend/                       # 💻 Vue.js 프론트엔드
├── molly-note-app/                # 📱 Laravel 기반 앱
├── public/                        # 🌐 정적 파일
├── clinic-dashboard.html          # 🏥 원장용 대시보드
└── README.md
```

---

## 🔗 **중요 링크**

### **개발 환경**
- **API 서버**: `https://cautious-carnival-969vp5xpgv9hp46j-5003.app.github.dev/demo-project/us-central1/api`
- **Swagger UI**: `/api-docs`
- **원장 대시보드**: `http://localhost:8080/clinic-dashboard.html`

### **카카오 연동**
- **카카오비즈니스**: https://center-pf.kakao.com/
- **카카오 i 오픈빌더**: https://i.kakao.com/

### **배포 가이드**
- [최종 통합 가이드](../FINAL_INTEGRATION_GUIDE.md)
- [카카오톡 20분 미션](../KAKAO_20MIN_MISSION.md)
- [템플릿 모음](../KAKAO_TEMPLATES.md)

---

## 👥 **팀 & 역할**

### **핵심 팀**
- **대표**: 전략 수립, 비전 제시
- **개발팀**: 백엔드, 프론트엔드, AI 개발
- **디자인팀**: UX/UI, 브랜딩
- **의료자문**: 의료진 검토, 안전성 확보

### **협력 체계**
- **일일 스탠드업**: 진행 상황 공유
- **주간 리뷰**: 목표 달성도 점검
- **월간 전략 회의**: 방향성 조정

---

## 📊 **성과 지표 (KPI)**

### **개발 KPI**
- **API 응답 시간**: <200ms
- **시스템 가용성**: >99.9%
- **사용자 만족도**: >4.5/5.0

### **비즈니스 KPI**
- **사용자 증가율**: 월 20%+
- **리텐션 레이트**: 30일 >60%
- **NPS 점수**: >50

### **의료 KPI**
- **진료 시간 단축**: 30%+
- **환자 만족도**: >90%
- **의료진 만족도**: >85%

---

## 🔮 **로드맵**

### **Q3 2025: MVP 완성**
- [x] 백엔드 API 완성
- [x] 카카오톡 연동 완료
- [ ] 실제 병원 파일럿 테스트
- [ ] AI 분석 엔진 MVP

### **Q4 2025: 스케일업**
- [ ] 국내 의료기관 5곳 도입
- [ ] Mollynote 글로벌 베타 출시
- [ ] 시리즈 A 투자 유치

### **2026: 글로벌 확장**
- [ ] 영어권 시장 진출
- [ ] AI 정확도 95%+ 달성
- [ ] 100만 사용자 달성

---

## 📞 **연락처 & 지원**

### **개발 지원**
- **GitHub**: [MKM Lab Repository](https://github.com/mkmlab/mkmlab-v3)
- **Discord**: MKM Lab Dev Team
- **Email**: dev@mkmlab.com

### **비즈니스 문의**
- **Email**: business@mkmlab.com
- **Phone**: +82-2-XXXX-XXXX

---

**"매일의 혁명이 평생의 진화를 만든다"**  
**Daily Revolution Creates Lifelong Evolution**

**MKM Lab & Mollynote**  
**2025년 7월 11일**
