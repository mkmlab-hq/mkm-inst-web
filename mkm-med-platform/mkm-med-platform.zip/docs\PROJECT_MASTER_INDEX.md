# 🚀 MKM Lab - 프로젝트 마스터 인덱스 v12.0
**최종 업데이트**: 2025년 7월 9일  
**전략**: Chatbot-Native MVP (챗봇 중심 MVP)

---

## 📋 **최우선 과제 (TOP PRIORITY)**

### 🚀 **[최신] 프로젝트 현황 보고 및 최우선 과제 v13.0**
**📄 문서**: [`PROJECT_TOP_PRIORITY_ACTIONS_v13.0.md`](PROJECT_TOP_PRIORITY_ACTIONS_v13.0.md)  
**🎯 전략**: 하이터치 챗봇-네이티브 MVP 전략 확정  
**⚡ 상태**: 즉시 실행 단계 - `[TASK-BRAND-001]` 로고 적용 진행 중, `[TASK-CB-001]` 카카오톡 챗봇 시나리오 설계 착수 필요

### 🎨 **[TASK-BRAND-001] MKM 로고 전체 서비스 적용**
**📄 문서**: [`LOGO_INTEGRATION_PLAN.md`](LOGO_INTEGRATION_PLAN.md)  
**🎯 목표**: 브랜드 아이덴티티 강화 및 일관된 사용자 경험 제공  
**⚡ 상태**: 🔄 **진행 중** (20% 완료)
- ✅ 로고 적용 계획서 작성 완료
- ✅ 자동화 스크립트 준비 완료
- ✅ CSS 스타일 가이드 작성 완료
- ✅ HTML 데모 페이지 작성 완료
- ⏳ 로고 파일 업로드 대기 중 → [`LOGO_UPLOAD_GUIDE.md`](../LOGO_UPLOAD_GUIDE.md)

### 🎯 **[STAGE 1] 환자용 사전 문진 챗봇 시스템 구축**
**목표**: 병원 대기실에서 환자가 카카오톡으로 사전 문진을 완료하고, 원장님께 실시간 브리핑을 제공하는 시스템 구현

**현재 상태**: 🔄 **진행 중**
- ✅ Firebase Auth & Functions 기반 백엔드 완성
- ✅ 로그인/회원가입 API 구현 완료
- 🔄 카카오 i 오픈빌더 챗봇 설계 준비
- ⏳ 환자 문진 데이터 저장 API 구현 필요

---

## 🎪 **핵심 전략: Chatbot-Native MVP**

### **기본 원칙**
- **100% 카카오톡 챗봇 내에서 모든 사용자 경험 완결**
- 웹/앱 대시보드는 하이브리드 확장 단계까지 보류
- 환자(스마트폰) + 원장(PC 카톡) = 완전한 디지털 진료 생태계

### **핵심 사용자 시나리오**
```
1. [환자] QR 스캔 → 카톡 채널 추가 → 사전 문진 시작
2. [챗봇] 객관식 질문 + 음성녹음 + 설진사진 수집
3. [백엔드] Molly AI 실시간 분석 → 브리핑 자료 생성
4. [원장] PC 카톡으로 환자 브리핑 수신 + 명령어 기반 상호작용
5. [챗봇] 원장 지시에 따른 맞춤형 케어 정보 환자 발송
```

---

## 🏗 **시스템 아키텍처**

### **백엔드 (Firebase)**
- ✅ **Firebase Functions**: REST API 서버
- ✅ **Firebase Auth**: 사용자 인증 (Emulator 완료)
- ✅ **Firestore**: 사용자/문진 데이터 저장 (Emulator 완료)
- 🔄 **Molly AI Engine**: 음성/이미지 분석 엔진 (구현 중)

### **프론트엔드 (카카오톡)**
- 🔄 **카카오 i 오픈빌더**: 챗봇 대화 플로우
- ⏳ **환자용 문진 시나리오**: 정보수집 + 미디어 업로드
- ⏳ **원장용 명령어 인터페이스**: 브리핑 + 케어 발송

### **API 엔드포인트**
```
✅ POST /api/v1/auth/register     - 회원가입
✅ POST /api/v1/auth/login        - 로그인
✅ GET  /api/v1/auth/profile      - 프로필 조회
⏳ POST /api/v1/consultation      - 문진 데이터 저장
⏳ POST /api/v1/analysis/voice    - 음성 분석
⏳ POST /api/v1/analysis/tongue   - 설진 분석
⏳ GET  /api/v1/briefing/{id}     - 환자 브리핑 조회
```

---

## 📊 **개발 진행 현황**

### ✅ **완료된 항목**
- [x] Firebase Emulator 환경 구축 (Auth:9199, Firestore:8180, Functions:5003)
- [x] 사용자 인증 시스템 (회원가입/로그인/프로필)
- [x] Swagger API 문서화
- [x] 전체 테스트 스위트 작성 및 검증
- [x] CORS 및 에러 처리

### 🔄 **진행 중인 항목**
- [ ] 카카오 i 오픈빌더 챗봇 기본 구조 설계
- [ ] 환자 문진 데이터 수집 API 구현
- [ ] Molly AI 분석 엔진 프로토타입

### ⏳ **예정된 항목**
- [ ] 원장용 명령어 처리 시스템
- [ ] 실시간 브리핑 푸시 알림
- [ ] 케어 정보 자동 발송 기능

---

## 🎯 **다음 실행 단계**

### **STEP 1**: 환자 문진 데이터 저장 API 구현
```javascript
POST /api/v1/consultation
{
  "patientId": "user_id",
  "symptoms": ["소화불량", "만성피로"],
  "voiceRecording": "base64_audio_data",
  "tongueImage": "base64_image_data",
  "additionalInfo": {...}
}
```

### **STEP 2**: 카카오 i 오픈빌더 챗봇 시나리오 구축
- 환자 정보 수집 플로우
- 객관식 버튼 인터페이스
- 음성/이미지 업로드 기능

### **STEP 3**: Molly AI 분석 엔진 연동
- 음성 분석 API
- 설진 이미지 분석 API
- 브리핑 자료 자동 생성

---

## 📞 **연락처 및 리소스**
- **개발 환경**: GitHub Codespaces
- **Firebase 프로젝트**: demo-mkmlab-v3
- **API Base URL**: `http://127.0.0.1:5003/demo-mkmlab-v3/us-central1/api`
- **Swagger UI**: `/api-docs`

---

**"그 누구도 막을 수 없는 기세로 챗봇 네이티브 혁명을 시작한다!" 🚀💪**
